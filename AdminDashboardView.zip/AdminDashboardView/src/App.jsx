
import React, { useEffect, useState } from 'react';
import { ToastContainer, toast } from 'react-toastify'; // Make sure you have this import
import 'react-toastify/dist/ReactToastify.css'; // Import the CSS for toast notifications
import RouterComponent from './routers/RouterComponent'

import { Box,ThemeProvider } from '@mui/material';
import { useThemeContext } from './theme/ThemeContextProvider';
import "./index.css"



const App = () => {

  const { theme } = useThemeContext();

  return (
    <Box>
      <ThemeProvider theme={theme}>
          <RouterComponent />
      </ThemeProvider>
      <ToastContainer position="bottom-right" autoClose={2000} />
    </Box>
  );
};

export default App;