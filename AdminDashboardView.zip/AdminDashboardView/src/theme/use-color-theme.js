
import { createTheme } from "@mui/material";
import React from "react";
import useThemeColors, { getDesignTokens } from "./theme"; // Ensure correct import path

export const useColorTheme = () => {
  const [mode, setMode] = React.useState("light");
  const { settings, handleColorChange,selectedPrimaryColor,selectedSecondaryColor } = useThemeColors(); // Access settings from the theme hook

  const toggleColorMode = () => {
    setMode((prevMode) => (prevMode === "light" ? "dark" : "light"));
  };

  const modifiedTheme = React.useMemo(
    () => createTheme(getDesignTokens(mode, { primaryColor: settings.primaryColor , secondaryColor:settings.secondaryColor })),
    [mode, settings.primaryColor, settings.secondaryColor]
  );

  return {
    theme: modifiedTheme,
    mode,
    toggleColorMode,
    selectedPrimaryColor,
    selectedSecondaryColor,
    handleColorChange,
    
  };
};
