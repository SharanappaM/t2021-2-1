
import { grey } from "@mui/material/colors";

export const getDesignTokens = (mode, { primaryColor, secondaryColor }) => ({
  palette: {
    mode,
    ...(mode === "light"
      ? {
        primary: { 
          main: primaryColor ,
          contrastText: '#ffffff'
        },
        secondary: {
          main: secondaryColor,
          contrastText: '#ffffff'
        },
        navbarColor: {
          main: "#FFFFFF" // White

        },
        contentBgColor: {
          main: "#f8f9f9" // white blue 
        }
        ,
        text: {
          primary: grey[900],
          secondary: grey[800],
        },
       
      }
      : {


        navbarColor: {
          main: "#FFFFFF" // white 

        },

        contentBgColor: {
          main: "#171821" // Grey Black (bg color)

        },
        // palette values for dark mode
        primary: {
          main: "#171821" // Grey Black (bg color)
        },
        secondary: {
          main: secondaryColor
        },



        divider: "#21222D",
        background: {
          default: "#171821",
          paper: "#21222D" // light Grey (form Color card)
        },
        text: {
          primary: "#fff",
          secondary: "#fff",
        },
      }),
  },
});





import { createTheme } from "@mui/material/styles";
import { useState } from "react";


const useThemeColors = () => {
  const [settings, setSettings] = useState({
    primaryColor: '#1b1a47', // Default primary color
    secondaryColor: '#C39BD3',
    mode: 'light', // or 'dark'
  });
  const [selectedPrimaryColor, setSelectedPrimaryColor] = useState(settings.primaryColor)
  const [selectedSecondaryColor, setSelectedSecondaryColor] = useState(settings.secondaryColor)

  const handleColorChange = (color, isPrimary) => {
    setSettings((prev) => ({
      ...prev,
      [isPrimary ? 'primaryColor' : 'secondaryColor']: color.hex,
    }));
    if (isPrimary) {

      setSelectedPrimaryColor(color.hex)
    } else {
      setSelectedSecondaryColor(color.hex)
    }




  };

  return {
    settings,
    selectedPrimaryColor,
    selectedSecondaryColor,
    handleColorChange,

  };
};

// Export the hook as default
export default useThemeColors;


