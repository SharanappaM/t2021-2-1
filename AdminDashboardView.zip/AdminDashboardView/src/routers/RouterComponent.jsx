import React, {Suspense, useEffect, useState } from 'react'
import { Outlet, Route, Routes } from 'react-router-dom'
import Dashboard from '../components/layouts/dashboard/Dashboard'
import DashboardWellComePage from '../components/layouts/dashboard/DashboardWellComePage'
import { AuthProvider } from '../components/context/AuthContext'
import PageNotFound from '../components/pages/PageNotFound/PageNotFound'
import MyAccount from '../components/myAccount/MyAccount'
import ProtectedRoute from '../components/context/ProtectedRoute'
import ManageIPAe from '../components/pages/OTA/mangeIPAe/ManageIPAe'
import LoginPage from '../components/landingPage/loginPage/LoginPage'
const RouterComponent = () => {

    const [role, setRole] = useState("");

    useEffect(() => {
        const storedRole = sessionStorage.getItem('userRole');
        if (storedRole) {
            setRole(storedRole);
        }
    }, []);


    return (
        <>
            <AuthProvider>
                <Routes>
                    <Route path='/' element={<LoginPage />} />
                    <Route element={<ProtectedRoute />}>
                        <Route path={`/:role`} element={<Dashboard />} >
                            <Route path='myAccount' element={<MyAccount />} />
                            <Route path='' element={<DashboardWellComePage />} />
                            <Route path='*' element={<PageNotFound />} />
                            <Route path='manage-IPAe' element={<ManageIPAe />} />
                        </Route>
                    </Route>
                </Routes>
            </AuthProvider>

            <Suspense>
                <Outlet />
            </Suspense>


        </>
    )
}

export default RouterComponent



