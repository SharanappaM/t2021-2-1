
import React, { createContext, useContext, useState } from 'react'
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { Box, Button, FormControl, IconButton, Input, InputAdornment, InputLabel, Menu, MenuItem, Paper, Stack, Tab, Tabs, TextField, Typography, styled } from '@mui/material'

import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import LockIcon from '@mui/icons-material/Lock';
import { useNavigate } from 'react-router-dom';
import logo from "./../../../assets/logo.png"

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { AuthContext } from '../../context/AuthContext';
import { useThemeContext } from '../../../theme/ThemeContextProvider';
import axios from 'axios';

const SubmitButton = styled(Button)({
    borderRadius: "10px",
    boxShadow: "none",
    marginLeft: "10px",
    marginTop: "15px"

})








const LoginPage = () => {
    const navigate = useNavigate()
    const { login } = useContext(AuthContext)
    const [role, setRole] = useState("OTA");
    const { mode } = useThemeContext()

    const [email, setEmail] = useState(null)
    const [password, setPassword] = useState(null)

    const [userData, setUserData] = useState({
        email: null,
        password: null
    })

    const [showPassword, setShowPassword] = useState(false);
    const handleClickShowPassword = () => setShowPassword((show) => !show);
    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

  


    // Hardcoded users for testing
    const validUsers = [
        { email: 'admin@travercel.com', password: 'travercel@2019' },
        { email: 'testeim@travercel.com', password: 'travercel@2024' },

    ];

    // Generate session token using email (now without timestamp)
    const generateSessionToken = (email) => {
        const secret = 'your-very-secret-key';  // A static secret key for consistency
        const rawToken = `${email}:${secret}`; // Combine email and secret
        return btoa(rawToken);  // Base64 encode the raw token
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        // Find user by matching email and password
        const user = validUsers.find(
            (user) => user.email === email && user.password === password
        );

        if (user) {
            console.log('Login successful. Storing token.');

            // Generate the session token and store it in localStorage
            const token = generateSessionToken(email);
            localStorage.setItem('sessionToken', token);
            localStorage.setItem('userEmail', email);
            login(role);
            sessionStorage.setItem('userRole', role);
            navigate(`/${role}`);

        } else {
            toast.error("Invalid username or password!")
            console.log('Login failed');
        }
    };



 


    return (
        <>

            <ToastContainer position='bottom-right' />
            <Box width="100%" bgcolor={mode === "light" ? "#f5f5f5" : "#171821"}>
                <Box display='flex' justifyContent="center"  >
                <Box sx={{
                            width: {
                                xs: "90%",
                                sm: "80%",
                                md: "70%",
                                lg: "60%",
                                xl: "60%"
                            },
                          

                        }}>
                            <Box sx={{
                                display: {
                                    xs: "block",
                                    sm: "none",
                                    md: "none",
                                    lg: "block",
                                    xl: "none"
                                },

                                marginLeft: "22%"


                            }}>
                                {/* <img src={logo} alt="" width={200} /> */}
                            <Typography variant='h4' sx={{
                                fontWeight:"bold",
                                ml:3,
                                mb:3
                            }}>
                                Operator 
                            </Typography>
                            </Box>


                            <form action="" onSubmit={handleSubmit}>
                            <Typography variant='h5' sx={{
                                fontWeight:"bold",
                                ml:2,
                                mb:3
                            }}>
                                Operator 
                            </Typography>

                                <Stack direction="column" >
                                    <Stack direction="row" spacing={1} >
                                        <IconButton >
                                            <AccountCircleIcon sx={{
                                                fontSize: "30px",
                                                marginTop: "12px"
                                            }} />
                                        </IconButton>
                                        <TextField
                                            name='email' value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            color={mode === "light" ? "primary" : "secondary"}

                                            fullWidth
                                            id="email"
                                            label={role}
                                            type="email"
                                            autoComplete="email"
                                            variant="standard"
                                        />
                                    </Stack>


                                    <Stack direction="row" spacing={1}>
                                        <IconButton>
                                            <LockIcon sx={{
                                                fontSize: "30px",
                                                marginTop: "12px"
                                            }} />
                                        </IconButton>
                                        <FormControl fullWidth variant="standard">
                                            <InputLabel color={mode === "light" ? "primary" : "secondary"} htmlFor="standard-adornment-password">password</InputLabel>
                                            <Input
                                                name='password'
                                                value={password}
                                                color={mode === "light" ? "primary" : "secondary"}

                                                onChange={(e) => setPassword(e.target.value)}

                                                fullWidth
                                                id="standard-adornment-password"
                                                type={showPassword ? 'text' : 'password'}
                                                endAdornment={
                                                    <InputAdornment position="end">
                                                        <IconButton
                                                            aria-label="toggle password visibility"
                                                            onClick={handleClickShowPassword}
                                                            onMouseDown={handleMouseDownPassword}
                                                        >
                                                            {showPassword ? <Visibility /> : <VisibilityOff />}
                                                        </IconButton>
                                                    </InputAdornment>
                                                }
                                            />
                                        </FormControl>
                                    </Stack>


                                </Stack>
                                <SubmitButton type='submit' color={mode === "light" ? "primary" : "secondary"} variant='contained' fullWidth>Submit</SubmitButton>
                            </form>


                        </Box>
                </Box>
            </Box>
        </>
    )
}

export default LoginPage

