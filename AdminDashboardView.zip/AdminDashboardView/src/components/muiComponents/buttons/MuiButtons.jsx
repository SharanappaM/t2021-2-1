import { Box, Button, styled } from "@mui/material"




const CustomButtonSubmit = styled(Button)(({ theme }) => ({
    '&:hover': {
        background: theme.palette.primary.main,
        color: theme.palette.navbarColor.main,

    },
    fontWeight: "bolder"
}))

const CustomButtonCancel = styled(Button)(({ theme }) => ({
    '&:hover': {
        background: theme.palette.error.main,
        color: theme.palette.navbarColor.main,

    },
    fontWeight: "bold"
}))
const CustomButtonRemove = styled(Button)(({ theme }) => ({
    '&:hover': {
        background: theme.palette.error.main,
        color: theme.palette.navbarColor.main,

    },
    fontWeight: "bold"
}))


export const CustomMuiSubmitButton = () => <Box>
    <CustomButtonSubmit type="submit" color="primary" variant="outlined">Submit</CustomButtonSubmit>

</Box>;







import React, { useEffect, useState } from 'react'
import { useNavigate } from "react-router-dom";
import { useThemeContext } from "../../../theme/ThemeContextProvider";

const CustomMuiCancelButton = () => {
    const { selectedSecondaryColor } = useThemeContext();

    const [role, setRole] = useState("");

    const navigate= useNavigate()

    useEffect(() => {
        const storedRole = sessionStorage.getItem('userRole');
        if (storedRole) {
            setRole(storedRole);
        }
    }, []);


    const handleExit = ()=>{
        navigate(`/${role}`)
    }

    return (
        <Box>
            <CustomButtonCancel onClick={handleExit} color="error" variant="outlined">Cancel</CustomButtonCancel>

        </Box>
    )
}

export default CustomMuiCancelButton