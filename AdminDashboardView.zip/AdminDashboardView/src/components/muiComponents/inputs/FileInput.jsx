import React, { forwardRef } from 'react';
import { useThemeContext } from '../../../theme/ThemeContextProvider';


const FileInput = forwardRef(({ onChange ,accept}, ref) => {
  const { mode } = useThemeContext();
  
  return (
    <input
      className='form-control'
      style={{
        border: "none",
        background: mode === "light" ? "#fff" : "#21222D",
        color: mode === "light" ? "#21222D" : "#fff",
      }}
      required
      ref={ref}
      onChange={onChange}
      type="file"
      accept={accept}  
    />
  );
});
export default FileInput;