import React from "react";

const ManageIPAe = () => {

  return (
    <div>
      Manage IPAe
    </div>
  );
};

export default ManageIPAe;
