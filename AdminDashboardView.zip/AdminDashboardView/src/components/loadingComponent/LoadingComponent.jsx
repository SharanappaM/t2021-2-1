import React from 'react'
import "./loadingComponent.css"
import { Backdrop } from '@mui/material'

const LoadingComponent = () => {
    return (
        <>

            <Backdrop
                sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={true}
            >
                <div className="loading">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>

            </Backdrop>



          
        </>
    )
}

export default LoadingComponent