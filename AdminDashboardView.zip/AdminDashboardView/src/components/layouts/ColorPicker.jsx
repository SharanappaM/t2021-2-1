import React from 'react';

const ColorPicker = ({ onChange, label }) => {
  const handleChange = (event) => {
    const color = { hex: event.target.value }; // Create a color object
    onChange(color);
  };

  return (
    <div>
      <label>{label}</label>
      <input type="color" onChange={handleChange} />
    </div>
  );
};

export default ColorPicker;