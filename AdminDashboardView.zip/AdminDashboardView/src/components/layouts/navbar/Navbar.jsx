import {
  AppBar,
  Avatar,
  Badge,
  Box,
  CardContent,
  CssBaseline,
  Divider,
  Drawer,
  IconButton,
  ImageListItem,
  ListItemIcon,
  Menu,
  MenuItem,
  Modal,
  Toolbar,
  Tooltip,
  Typography,
  styled,
} from "@mui/material";

import { Card, Chip, Grid, Button } from "@mui/material";
import {
  AccessTime,
  CheckCircleOutline,
  ContentCopy,
} from "@mui/icons-material";


const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  borderRadius: "12px", // Rounded corners
  boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)", // Softer shadow for depth
  p: 3, // Increased padding
  transition: "all 0.3s ease", // Smooth transition on hover
  
  "&:hover": {
    boxShadow: "0 6px 30px rgba(0, 0, 0, 0.15)", // Hover effect for depth
  },
};

import React, { useEffect, useState } from "react";

import { CompanyLOGO1 } from "../../../envComponents/EnvironmentComponent";
import { Link, useNavigate, useParams } from "react-router-dom";
import PreviewIcon from "@mui/icons-material/Preview";

import LogoutIcon from "@mui/icons-material/Logout";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import NotificationsIcon from "@mui/icons-material/Notifications";
import CloseIcon from "@mui/icons-material/Close";
import DehazeIcon from "@mui/icons-material/Dehaze";
import Sidebar from "../sidebar/Sidebar";
import Brightness4Icon from "@mui/icons-material/Brightness4";
import Brightness7Icon from "@mui/icons-material/Brightness7";
import { useThemeContext } from "../../../theme/ThemeContextProvider";
import { Logout, PersonAdd, Settings } from "@mui/icons-material";
import SockJS from "sockjs-client";
import { Client } from "@stomp/stompjs";
import CancelIcon from "@mui/icons-material/Cancel";

const StyledCard = styled(Box)(({ theme }) => ({
  // color: active ? `${selectedSecondaryColor}` : theme.palette.navbarColor.main,
  position: "relative",
  "&::before": {
    content: '""',
    position: "absolute",
    top: 0,
    left: 0,
    width: "5px",
    height: "100%",
    backgroundColor: theme.palette.primary,
  },
}));

// Custom Hook for Local Storage
function useMessageStorage() {
  const storageKey = "messages"; // Change this to your desired key

  const getMessages = () => {
    const storedData = localStorage.getItem(storageKey);
    return storedData ? JSON.parse(storedData) : [];
  };

  const addMessage = (message) => {
    const timestamp = Date.now();
    const newMessage = { content: message, timestamp };
    const existingMessages = getMessages();

    const updatedMessages = [...existingMessages, newMessage];
    localStorage.setItem(storageKey, JSON.stringify(updatedMessages));
  };

  const removeMessage = (timestamp) => {
    const existingMessages = getMessages();

    const updatedMessages = existingMessages.filter(
      (msg) => msg.timestamp !== timestamp
    );
    localStorage.setItem(storageKey, JSON.stringify(updatedMessages));
  };

  return { getMessages, addMessage, removeMessage };
}



function Message({ content, timestamp, onSeenClick }) {
  const formattedTimestamp = new Date(timestamp).toLocaleString();
  const parsedContent = JSON.parse(content); // Parse the content JSON

  const [isCopied, setIsCopied] = useState(false);
  const [viewNotificationDetails, setViewNotificationDetails] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(parsedContent.remoteStringResponse);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000); // Reset after 2 seconds
  };

  // const truncatedEuiccResponse =
  //   parsedContent.remoteStringResponse.length > 50
  //     ? parsedContent.remoteStringResponse.slice(0, 26) + "...."
  //     : parsedContent.remoteStringResponse;

  return (
    <>
      <Modal
        open={viewNotificationDetails}
        onClose={() => setViewNotificationDetails(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Box>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Typography
                variant="h6"
                sx={{ fontWeight: "bold", color: "primary.main" }}
              >
                Notification Data
              </Typography>
              <IconButton
                onClick={() => setViewNotificationDetails(false)}
                sx={{
                  p: 0,
                  color: "error.main",
                  "&:hover": {
                    backgroundColor: "transparent",
                    transform: "scale(1.1)", // Button hover effect
                  },
                  transition: "transform 0.3s ease",
                }}
              >
                <CancelIcon />
              </IconButton>
            </Box>

            <Divider
              variant="fullWidth"
              sx={{
                margin: "8px 0",
                borderColor: "rgba(0, 0, 0, 0.1)", // Subtle divider color
              }}
            />

            {/* Display data directly from parsedContent */}
            <Typography
              variant="body2"
              color="textSecondary"
              sx={{ marginBottom: "8px" }}
            >
              <strong>Package No:</strong> {parsedContent.seqNumber}
            </Typography>

            <Typography
              variant="body2"
              color="textSecondary"
              sx={{ marginBottom: "8px" }}
            >
              <strong>ICCID:</strong> {parsedContent.iccid}
            </Typography>

            <Typography
              variant="body2"
              color="textSecondary"
              sx={{ marginBottom: "8px" }}
            >
              <strong>Status Word:</strong> {parsedContent.statusWord}
            </Typography>

            <Typography
              variant="body2"
              color="textSecondary"
              sx={{ wordBreak: "break-word" }}
            >
              <strong>Response:</strong>
              <span>
                {parsedContent.remoteStringResponse}
                <Tooltip title="Copy eUICC Response" arrow placement="top">
                  <IconButton
                    onClick={handleCopy}
                    size="small"
                    sx={{
                      ml: 1,
                      color: "primary.main",
                      "&:hover": {
                        backgroundColor: "transparent",
                        transform: "scale(1.1)", // Copy icon hover effect
                      },
                    }}
                  >
                    <ContentCopy />
                  </IconButton>
                </Tooltip>
              </span>
            </Typography>

            {isCopied && (
                <Typography variant="body2" color="primary">
                  Copied!
                </Typography>
              )}
          </Box>
        </Box>
      </Modal>

      <Card
        sx={{
          maxWidth: "100%",
          margin: "15px auto",
          borderRadius: 2,
          overflow: "hidden",
          border: "0.5px solid #e0e0e0",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
          width: { xs: "100%", sm: 400 }, // Makes the card 100% width on mobile and 400px on larger screens
        }}
      >
        <Box
          sx={{
            pr: 2,
            pt: 2,
            pb: 2,
            width: "100%", // Ensures full width of the box
          }}
        >
          <Box display="flex">
            <Box
              sx={{
                width: 6,
                bgcolor: "plum",
                mr: 1,
                borderRadius: 1,
              }}
            ></Box>

            <Box
              sx={{
                width: "100%", // Ensures the content area stretches fully
              }}
            >
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                width="100%"
                // mb={2}
              >
                <Typography
                  variant="body1"
                  fontWeight="bold"
                  sx={{ wordBreak: "break-word" }}
                >
                  New Notification
                </Typography>
                <Tooltip
                  title="View Notification Data"
                  arrow
                  placement="left-start"
                >
                  <IconButton
                    onClick={() => setViewNotificationDetails(true)} // Directly open modal on click
                    size="medium"
                  >
                    <PreviewIcon />
                  </IconButton>
                </Tooltip>
              </Box>

              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                sx={{ flexWrap: "wrap", width: "100%" }}
              >
                <Box
                  display="flex"
                  alignItems="center"
                  sx={{ flexWrap: "wrap" }}
                >
                  <AccessTime sx={{ mr: 1 }} fontSize="small" />
                  <Typography
                    variant="body2"
                    color="textSecondary"
                    sx={{ wordBreak: "break-word" }}
                  >
                    <strong>Time:</strong>{" "}
                    {new Date(parsedContent.completionTimestamp).toLocaleString()}
                  </Typography>
                </Box>

                <Button
                  onClick={() => onSeenClick(timestamp)}
                  variant="contained"
                  color="primary"
                  size="small"
                  startIcon={<CheckCircleOutline />}
                  sx={{
                    textTransform: "none",
                    borderRadius: 2,
                    ml: "7px",
                    "&:hover": {
                      backgroundColor: "#2e7d32",
                    },
                  }}
                >
                  Mark as Read
                </Button>
              </Box>

           
            </Box>
          </Box>
        </Box>
      </Card>
    </>
  );
}


const Navbar = () => {
  const { getMessages, addMessage, removeMessage } = useMessageStorage();
  const [messages, setMessages] = useState(getMessages());
  const [notificationCount, setNotificationCount] = useState(null);
  const [openSidebar, setOpenSidebar] = useState(false);
  const { mode, toggleColorMode } = useThemeContext();
  let { role } = useParams();
  const [openNotificationDrawer, setOpenNotificationDrawer] = useState(false);

  const navigate = useNavigate();

  const storedToken = localStorage.getItem("sessionToken");
  const userEmail = localStorage.getItem("userEmail");

  const logout = () => {
    localStorage.removeItem("sessionToken");
    localStorage.removeItem("userEmail");
    navigate("/");
  };

  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleAccountSettings = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleAccountSettingsClose = () => {
    setAnchorEl(null);
    navigate("myAccount");
  };


  useEffect(() => {
    const socket = new SockJS("http://localhost:9595/ws");
    const client = new Client({
      brokerURL: "ws://localhost:9595/ws", // WebSocket server URL
      connectHeaders: {},
      debug: function (str) {
        console.log(str); // Debugging the connection
      },
      onConnect: () => {
        console.log("Connected to WebSocket");
        // Subscribe to a topic
        client.subscribe("/topic/messages", (messageOutput) => {
          console.log("Received message:", messageOutput.body);
          addMessage(messageOutput.body); // Update state with the received message
          setMessages(getMessages());
        });
      },
      onStompError: (error) => {
        console.log("STOMP Error:", error);
      },
    });
    client.webSocketFactory = () => socket;
    client.activate(); // Activate the connection
    // Clean up the WebSocket connection when the component unmounts
    return () => {
      if (client && client.connected) {
        client.deactivate();
      }
    };
  }, []); // Empty dependency array to only run this once on mount

  const handleSeenClick = (timestamp) => {
    removeMessage(timestamp); // Remove the message from localStorage
    setMessages(getMessages()); // Update state
  };

  useEffect(() => {
    setNotificationCount(messages.length);
  });

  return (
    <>
      <CssBaseline />
      <AppBar
        elevation={0}
        color="navbarColor"
        variant="outlined"
        position="fixed"
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
          bgcolor: mode === "light" ? "#fff" : "#171821",
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between", // Add this line
          }}
        >
          <Box
            sx={{
              display: "flex",
            }}
          >
            <Box
              sx={{
                display: {
                  xs: "block",
                  sm: "block",
                  md: "none",
                  lg: "none",
                  xl: "none",
                },
              }}
            >
              <IconButton onClick={() => setOpenSidebar(true)}>
                <DehazeIcon />
              </IconButton>
            </Box>

            <ImageListItem
              sx={{
                width: {
                  xs: 110,
                  sm: 125,
                  md: 140,
                  lg: 155,
                  xl: 160,
                },
              }}
            >
              <img src={CompanyLOGO1()} alt="" />
            </ImageListItem>
          </Box>

          <Box
            sx={{
              display: "flex",
              gap: {
                xs: 0,
                sm: 0,
                md: 2,
                lg: 2.5,
                xl: 3,
              },
            }}
          >
            <IconButton
              sx={{ ml: 1 }}
              onClick={toggleColorMode}
              color="inherit"
            >
              {mode === "dark" ? <Brightness4Icon /> : <Brightness7Icon />}
            </IconButton>

            <Tooltip arrow placement="bottom" title="Notifications">
              <IconButton
                onClick={() => setOpenNotificationDrawer(true)}
                color="inherit"
              >
                <Badge
                  color="error"
                  badgeContent={messages.length > 0 ? notificationCount : 0}
                >
                  <NotificationsIcon />
                </Badge>
              </IconButton>
            </Tooltip>

            <Tooltip arrow placement="bottom" title="Logout">
              <IconButton onClick={logout} color="inherit">
                <LogoutIcon />
              </IconButton>
            </Tooltip>

            <Box>
              {role === "SM-DP+" && (
                <Avatar sx={{ bgcolor: "#00A36C", fontSize: "50%" }}>
                  SM-DP+
                </Avatar>
              )}

              {role === "eIMClient" && (
                <Avatar sx={{ bgcolor: "#F6BE00", fontSize: "13px" }}>
                  eIM-C
                </Avatar>
              )}

              {role === "eIMOperator" && (
                <Avatar sx={{ bgcolor: "#9F000F", fontSize: "12px" }}>
                  eIM-O
                </Avatar>
              )}

              {role === "smds" && (
                <Avatar sx={{ bgcolor: "#D35400", fontSize: "13px" }}>
                  SMDS
                </Avatar>
              )}

              {role === "IPAe" && (
                <Avatar sx={{ bgcolor: "red", fontSize: "15px" }}>IPAe</Avatar>
              )}

              {role === "M2M" && (
                <Avatar sx={{ bgcolor: "#614051", fontSize: "15px" }}>
                  M2M
                </Avatar>
              )}
              {role === "OTA" && (
                <Avatar sx={{ bgcolor: "#614051", fontSize: "15px" }}>
                  OTA
                </Avatar>
              )}
              {role === "MultiClient" && (
                // <Avatar sx={{ bgcolor: "#614051", fontSize: "15px" }}>MC</Avatar>
                <Tooltip title="Account settings">
                  <IconButton
                    onClick={handleAccountSettings}
                    size="small"
                    sx={{ ml: 2 }}
                    aria-controls={open ? "account-menu" : undefined}
                    aria-haspopup="true"
                    aria-expanded={open ? "true" : undefined}
                  >
                    <Avatar sx={{ bgcolor: "#614051", fontSize: "15px" }}>
                      MC
                    </Avatar>
                  </IconButton>
                </Tooltip>
              )}
            </Box>
          </Box>
        </Toolbar>
      </AppBar>

      <Drawer
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
        }}
        anchor="right"
        onClose={() => setOpenNotificationDrawer(false)}
        open={openNotificationDrawer}
      >
        <Box
          sx={{
            width: {
              xs: 250,
              sm: 270,
              md: 300,
              lg: 420,
              xg: 360,
            },
          }}
        >
          <Box position="sticky" top={0} left={0} zIndex={1000}>
            <Box display="flex" justifyContent="space-between" padding={1}>
              <Typography variant="h6">Notifications</Typography>
              <IconButton onClick={() => setOpenNotificationDrawer(false)}>
                <HighlightOffIcon color="error" />
              </IconButton>
            </Box>
            <Divider />
          </Box>

          <Box>
            {messages.map((msg, index) => (
              <>
                <Message
                  key={index}
                  content={msg.content}
                  timestamp={msg.timestamp}
                  onSeenClick={handleSeenClick}
                />
              </>
            ))}
          </Box>
        </Box>
      </Drawer>

      <Drawer
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
          display: {
            xs: "block",
            sm: "block",
            md: "none",
            lg: "none",
            xl: "none",
          },
        }}
        anchor="left"
        open={openSidebar}
        onClose={() => setOpenSidebar(false)}
      >
        <Box
          width={250}
          height="100%"
          bgcolor="primary.main"
          sx={{ overflow: "auto" }}
        >
          <Sidebar />
        </Box>
      </Drawer>

      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleAccountSettingsClose}
        onClick={handleAccountSettingsClose}
        slotProps={{
          paper: {
            elevation: 0,
            sx: {
              overflow: "visible",
              filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
              mt: 1.5,
              "& .MuiAvatar-root": {
                width: 32,
                height: 32,
                ml: -0.5,
                mr: 1,
              },
              "&::before": {
                content: '""',
                display: "block",
                position: "absolute",
                top: 0,
                right: 14,
                width: 10,
                height: 10,
                bgcolor: "background.paper",
                transform: "translateY(-50%) rotate(45deg)",
                zIndex: 0,
              },
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <MenuItem onClick={handleAccountSettingsClose}>
          <Avatar /> My account
        </MenuItem>
        <Divider />

        <MenuItem onClick={handleAccountSettingsClose}>
          <ListItemIcon>
            <Settings fontSize="small" />
          </ListItemIcon>
          Settings
        </MenuItem>
        <MenuItem onClick={handleAccountSettingsClose}>
          <ListItemIcon>
            <Logout fontSize="small" />
          </ListItemIcon>
          Logout
        </MenuItem>
      </Menu>
    </>
  );
};

export default Navbar;
