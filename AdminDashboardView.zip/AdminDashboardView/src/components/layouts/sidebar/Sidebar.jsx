
import React, { useContext, useEffect, useState } from 'react';

import { Box, List, ListItemButton, ListItemIcon, ListItemText, Collapse, Divider, Typography, IconButton } from '@mui/material';
import { styled } from '@mui/system';
import {
    Dashboard as DashboardIcon,
    Description as DescriptionIcon,
    NoteAdd as NoteAddIcon,
    Search as SearchIcon,
    KeyboardArrowUp as KeyboardArrowUpIcon,
    KeyboardArrowDown as KeyboardArrowDownIcon,
    QueryStats as QueryStatsIcon,
    RecentActors as RecentActorsIcon,
    AccountCircle as AccountCircleIcon,
    Delete as DeleteIcon,
    Insights as InsightsIcon,
    ManageAccounts as ManageAccountsIcon,
    MergeType as MergeTypeIcon,
    Outbox as OutboxIcon,
    Lan as LanIcon,
    SimCardDownload as SimCardDownloadIcon,
    AutoFixHigh as AutoFixHighIcon,
    ManageHistory as ManageHistoryIcon,
    Storage as StorageIcon,
    EditCalendar as EditCalendarIcon,
    Dvr as DvrIcon,
    Widgets as WidgetsIcon,
    NotificationAdd as NotificationAddIcon,
} from '@mui/icons-material';
import SimCardIcon from '@mui/icons-material/SimCard';
import MemoryIcon from '@mui/icons-material/Memory';
import CellTowerIcon from '@mui/icons-material/CellTower';
import AppRegistrationIcon from '@mui/icons-material/AppRegistration';






import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { useThemeContext } from '../../../theme/ThemeContextProvider';
import SendIcon from '@mui/icons-material/Send';





const CustomDivider = styled(Divider)({
    backgroundColor: "#566573"
});

const Sidebar = () => {

    const { authState } = useContext(AuthContext);

    const [role, setRole] = useState(null)
    const [clientDetails, setClientDetails] = useState(null)



    useEffect(() => {
        const clientDetails = localStorage.getItem('clientDetails');
        const paredData = JSON.parse(clientDetails)
        setClientDetails(paredData)
        setRole(paredData?.role);

    }, []);





    const [activeMainItem, setActiveMainItem] = useState(null);
    const [activeSubItem, setActiveSubItem] = useState(null);
    const [openItems, setOpenItems] = useState({
        Profile: false,
        Template: false,
        ProfileSub: false,
        TemplateSub: false,
    });

    const { selectedSecondaryColor } = useThemeContext();



    const CustomListItemIcon = styled(ListItemIcon)(({ theme, active }) => ({
        color: active ? `${selectedSecondaryColor}` : theme.palette.navbarColor.main,
    }));

    const navigate = useNavigate()




    const handleMainItemToggle = (item, link) => {
        setActiveMainItem(item);
        setOpenItems((prevState) => ({
            Profile: item === 'Profile' ? !prevState.Profile : false,
            Template: item === 'Template' ? !prevState.Template : false,
            Employee: item === 'Employee' ? !prevState.Employee : false,
            eUM: item === "eUM" ? !prevState.eUM : false,
            Set: item === "Set" ? !prevState.Set : false,
            EIS: item === "EIS" ? !prevState.EIS : false,
            EISSub: false,
            SetSub: false,
            eUMSub: false,
            ProfileSub: false,
            TemplateSub: false,
        }));
        setActiveSubItem(null);

        // Navigate to the link if it's not Template or Profile
        if (item !== 'Template' && item !== 'Profile' && item !== "Employee") {
            navigate(`/${link}`);
        }


        localStorage.setItem('activeMainItem', item);
        localStorage.removeItem('activeSubItem');


    };


    useEffect(() => {
        const storedActiveMainItem = localStorage.getItem('activeMainItem');
        const storedActiveSubItem = localStorage.getItem('activeSubItem');

        if (storedActiveMainItem) {
            setActiveMainItem(storedActiveMainItem);
            setOpenItems((prev) => ({
                ...prev,
                [storedActiveMainItem]: true,
            }));
        }

        if (storedActiveSubItem) {
            setActiveSubItem(storedActiveSubItem);
        }
    }, []);





    const handleSubItemToggle = (subItem) => {
        setOpenItems((prevState) => ({
            ...prevState,
            [subItem]: !prevState[subItem],
        }));

        if (openItems[subItem]) {
            localStorage.removeItem('activeSubItem');
            setActiveSubItem(null);
        } else {
            localStorage.setItem('activeSubItem', subItem);
            setActiveSubItem(subItem);
        }
    };

    const renderSubItems = (mainItem, subItems) => (
        <Collapse in={openItems[mainItem]} timeout="auto" unmountOnExit sx={{ ml: 2 }}>
            {subItems.map(({ name, icon, subMenu, link }) => (
                <React.Fragment key={name}>
                    <ListItemButton
                        LinkComponent={Link}
                        to={link}
                        onClick={() => {
                            if (subMenu) {
                                handleSubItemToggle(subMenu.stateKey);
                            } else {
                                setActiveSubItem(name);
                            }
                        }}
                        sx={{
                            color: activeSubItem === name ? `${selectedSecondaryColor}` : 'navbarColor',
                            '&:hover': { color: `${selectedSecondaryColor}` },
                            m: 1,
                            borderRadius: "10px",
                        }}
                    >
                        <CustomListItemIcon active={activeSubItem === name}>{icon}</CustomListItemIcon>
                        <ListItemText primary={name} />
                        {subMenu && (openItems[subMenu.stateKey] ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />)}
                    </ListItemButton>
                    {subMenu && (
                        <Collapse in={openItems[subMenu.stateKey]} timeout="auto" unmountOnExit >
                            {renderSubItems(subMenu.stateKey, subMenu.items)}
                        </Collapse>
                    )}
                </React.Fragment>
            ))}
        </Collapse>
    );

    const SGP22MenuItems = [
        {
            name: 'Dashboard',
            icon: <DashboardIcon />,
            mainKey: 'Dashboard',
            link: ""
        },
        {
            name: 'Template',
            icon: <DescriptionIcon />,
            mainKey: 'Template',
            subItems: [
                { name: 'Create', icon: <NoteAddIcon />, link: "createTemplate" },
                {
                    name: 'Search', icon: <SearchIcon />, subMenu: {
                        stateKey: 'TemplateSub',
                        items: [
                            { name: 'Search By', icon: <QueryStatsIcon />, link: "searchTemplate" },
                            { name: 'Template List', icon: <RecentActorsIcon />, link: "templateList" },
                        ]
                    }
                },
            ]
        },
        {
            name: 'Profile',
            icon: <AccountCircleIcon />,
            mainKey: 'Profile',
            subItems: [
                { name: 'Create', icon: <NoteAddIcon />, link: "createProfile" },
                { name: 'Delete', icon: <DeleteIcon />, link: "deleteProfile" },
                {
                    name: 'Search', icon: <SearchIcon />, subMenu: {
                        stateKey: 'ProfileSub',
                        items: [
                            { name: 'Search By', icon: <QueryStatsIcon />, link: "searchBy" },
                            { name: 'Profile List', icon: <RecentActorsIcon />, link: "profileList" },
                        ]
                    }
                },
            ]
        }
    ];
  


    const OTAMenuItems = [
        {
            name: 'Dashboard',
            icon: <DashboardIcon />,
            mainKey: 'Dashboard',
            link: ""
        },
      
        {
            name: 'Manage IPAe',
            icon: <OutboxIcon />,
            mainKey: 'Manage IPAe',
            link: "manage-IPAe"
        },
  




    ];



    return (
        <Box height="100%" >
            <Box >

                {authState.userRole === "OTA" && (
                    <Box>
                        <List sx={{ color: "#ffffff" }}>
                            {OTAMenuItems.map(({ name, icon, mainKey, link }) => (
                                <Box key={mainKey}>
                                    <ListItemButton
                                        component={Link}
                                        to={link}
                                        onClick={() => handleMainItemToggle(mainKey, link)}
                                        sx={{
                                            backgroundColor: activeMainItem === mainKey ? `${selectedSecondaryColor}` : 'navbarColor',
                                            '&:hover': { background: `${selectedSecondaryColor}` },
                                            m: 1,
                                            borderRadius: "10px",
                                        }}
                                    >
                                        <CustomListItemIcon >{icon}</CustomListItemIcon>
                                        <ListItemText primary={name} />

                                    </ListItemButton>

                                </Box>
                            ))}
                        </List>
                    </Box>
                )}


                {
                    authState.userRole === "MultiClient" && (
                        <Box>
                            <List sx={{ color: "#ffffff" }}>
                                {MultiClientMenuItems.map(({ name, icon, mainKey, subItems, link }) => (
                                    <Box key={mainKey}>
                                        <ListItemButton
                                            component={Link}
                                            to={link}
                                            onClick={() => handleMainItemToggle(mainKey, link)}
                                            sx={{
                                                backgroundColor: activeMainItem === mainKey ? `${selectedSecondaryColor}` : 'navbarColor',
                                                '&:hover': { background: `${selectedSecondaryColor}` },
                                                m: 1,
                                                borderRadius: "10px",
                                            }}
                                        >
                                            <CustomListItemIcon >{icon}</CustomListItemIcon>
                                            <ListItemText primary={name} />
                                            {subItems && (openItems[mainKey] ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />)}
                                        </ListItemButton>
                                        {subItems && renderSubItems(mainKey, subItems)}
                                    </Box>
                                ))}
                            </List>
                        </Box>


                    )
                }
                {
                    authState.userRole === "null" && (

                        <Box>
                            <Typography>

                            </Typography>
                        </Box>

                    )
                }



            </Box>

            <Typography position="absolute" bottom={30} ml={7} color="white">{role}</Typography>

        </Box>


    );
};

export default Sidebar;

