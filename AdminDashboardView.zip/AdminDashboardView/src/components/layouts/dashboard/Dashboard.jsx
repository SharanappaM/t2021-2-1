
import React, { Suspense, useEffect, useState } from 'react'
import { Box, Divider, IconButton, Typography } from '@mui/material';
import { CssBaseline } from '@mui/material/';
import Drawer from '@mui/material/Drawer';
import SettingsIcon from '@mui/icons-material/Settings';
import Toolbar from '@mui/material/Toolbar';
import Sidebar from '../sidebar/Sidebar';
import Navbar from '../navbar/Navbar';
import { Outlet } from 'react-router-dom';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import { SketchPicker } from 'react-color';
import { useThemeContext } from '../../../theme/ThemeContextProvider';
const drawerWidth = 240;

const Dashboard = () => {

  const [drawOpen, setDrawOpen] = useState(true)
  const [role, setRole] = useState("");


  const [openSettingsDrawer, setOpenSettingsDrawer] = useState(false)

  const { settings, selectedPrimaryColor, selectedSecondaryColor, handleColorChange } = useThemeContext();
  const { mode } = useThemeContext();

  useEffect(() => {
    const storedRole = sessionStorage.getItem('userRole');
    if (storedRole) {
      setRole(storedRole);
    }
  }, []);


  const handlePrimaryColorChange = (color) => {
    handleColorChange(color, true); // Update primary color
  };
  const handleSecondaryColorChange = (color) => {
    handleColorChange(color, false); // Change secondary color
  };




  return (
    <Box width="100%" minHeight="100vh" bgcolor="contentBgColor.main" >
      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <Navbar />
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: 'border-box' },
            display: {
              xs: "none",
              sm: "none",
              md: "block",
              lg: "block",
              xl: "block",

            }
          }}

          open={drawOpen}
        >
          <Toolbar />

          <Box height="100%" bgcolor="primary.main" sx={{ overflow: 'auto', }}>
            <Sidebar />
          </Box>

        </Drawer>
        <Box component="main" sx={{ flexGrow: 1, }}>
          <Toolbar />



          <Box sx={{
            p: {
              xs: 3,
              sm: 3.5,
              md: 4,
              lg: 4.5,
              xl: 5
            }
          }} flex={5}   >
            <Suspense>
              <Box sx={{
                // bgcolor: "primary.main",
                bgcolor: mode === "light" ? selectedPrimaryColor : selectedSecondaryColor,
                borderTopLeftRadius: "15px",
                borderBottomLeftRadius: "15px",
                position: "fixed",
                right: 0, // Aligns to the right end of the container
              }}>
                <IconButton color='navbarColor'  onClick={() => setOpenSettingsDrawer(true)}>
                  <SettingsIcon />
                </IconButton>
              </Box>
              <Outlet />
            </Suspense>
          </Box>

        </Box>
      </Box>

      <Drawer
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
        }}
        anchor='right'
        onClose={() => setOpenSettingsDrawer(false)}
        open={openSettingsDrawer}
      >
        <Box sx={{
          width: {
            xs: 250,
            sm: 270,
            md: 300,
            lg: 350,
            xg: 360

          }
        }}>
          <Box position="sticky"  top={0} left={0} zIndex={1000}>
            <Box display="flex" justifyContent="space-between" padding={1} >
              <Typography variant='h6'>Theme Customizer</Typography>
              <IconButton onClick={() => setOpenSettingsDrawer(false)}>
                <HighlightOffIcon color='error' />
              </IconButton>

            </Box>
            <Divider />
          </Box>



          <Box sx={{
            padding: "10px"
          }}>

         

            <Box width="100%" display="flex" justifyContent="space-around">


              <Box >
                <SketchPicker
                  width='80%'
                  color={selectedPrimaryColor}
                  onChangeComplete={(color) => handleColorChange(color, true)}
                  styles={{
                    default: {
                      picker: {
                        boxShadow: 'none', // Remove the box shadow
                      },
                    },
                  }}
                />
                <Typography pl={2} color="primary.main">Primary Color</Typography>
              </Box>

              <Box >
                <SketchPicker
                  width='80%'
                  color={selectedSecondaryColor}
                  onChangeComplete={(color) => handleColorChange(color, false)}
                  styles={{
                    default: {
                      picker: {
                        boxShadow: 'none', // Remove the box shadow
                      },
                    },
                  }}
                />
                <Typography pl={2} color="secondary.main">Secondary Color</Typography>

              </Box>

            </Box>




          </Box>
        </Box>

      </Drawer>
    </Box>
  )
}

export default Dashboard