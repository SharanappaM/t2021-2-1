import React from 'react'

const DashboardWellComePage = () => {
  return (
    <div>
      DashboardWellComePage
    </div>
  )
}

export default DashboardWellComePage
