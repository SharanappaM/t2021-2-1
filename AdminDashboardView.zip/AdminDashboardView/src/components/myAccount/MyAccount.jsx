import { Box, Card, Grid, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react'

const MyAccount = () => {


  const [clientDetails, setClientDetails] = useState(null)


  useEffect(() => {
    const clientDetails = localStorage.getItem('clientDetails');

    const paredData = JSON.parse(clientDetails)
    setClientDetails(paredData)




  }, []);

  const parsedData = JSON.stringify(clientDetails)




  return (
    <Box>
     {parsedData}
    </Box>
  )
}

export default MyAccount