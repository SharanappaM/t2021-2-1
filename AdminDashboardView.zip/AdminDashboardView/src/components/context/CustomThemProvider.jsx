import { ThemeProvider, createTheme } from '@mui/material'
import React, { createContext, useState } from 'react'


export const ColorModeContext = createContext(null)
const CustomThemProvider = ({ children }) => {
  const [mode, setMode] = useState("light")

  const colorMode = () => {
    setMode((e) => (e === "light" ? "dark" : "light"))
  }

  const theme = createTheme({
    palette: {

      mode: mode,
      primary: {
        main: "#1b1a47"
      },
      secondary:{
        main:"#C39BD3"
      },
    
      
      navbarColor: {
        main: "#FFFFFF"

      },
      contentBgColor: {
        main: "#f8f9f9 "

      }

    },

    components: {
      MuiButton: {
        defaultProps: {
          disableRipple: true,
          disableElevation: true,

        },
     


      }
    }
  })




  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        {children}
      </ThemeProvider>
    </ColorModeContext.Provider>
  )
}

export default CustomThemProvider




