

import { Navigate, Outlet } from 'react-router-dom';

const generateSessionToken = (email) => {
  const secret = 'your-very-secret-key';  // Static secret key
  const rawToken = `${email}:${secret}`; // Combine email and secret
  return btoa(rawToken);  // Base64 encode the raw token
};

const ProtectedRoute = () => {
  const storedToken = localStorage.getItem('sessionToken');
  const userEmail = localStorage.getItem('userEmail');

  // If no sessionToken or userEmail, redirect to login
  if (!storedToken || !userEmail) {
    console.log('No session token or user email. Redirecting to login...');
    return <Navigate to="/" />;
  }

  // Validate token using the email and compare it to the stored token
  const expectedToken = generateSessionToken(userEmail);

  // If the stored token doesn't match the expected token, invalidate session
  if (storedToken !== expectedToken) {
    console.log('Invalid token. Redirecting to login...');
    localStorage.removeItem('sessionToken');
    localStorage.removeItem('userEmail');
    return <Navigate to="/" />;
  }

  return <Outlet />;
};


export default ProtectedRoute;
