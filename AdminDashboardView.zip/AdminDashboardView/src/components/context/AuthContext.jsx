import React, { createContext, useEffect, useState } from 'react';
export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [authState, setAuthState] = useState({
        isAuthenticated: sessionStorage.getItem("isAuthentication") === "true",
        userRole: sessionStorage.getItem("userRole"),
    });

    useEffect(() => {
        sessionStorage.setItem("isAuthentication", authState.isAuthenticated);
        sessionStorage.setItem("userRole", authState.userRole);
    }, [authState]);

    const login = (role) => {
        setAuthState({ isAuthenticated: true, userRole: role });
    };

    const logout = () => {
        setAuthState({ isAuthenticated: false, userRole: null });
        sessionStorage.removeItem("isAuthentication");
        sessionStorage.removeItem("userRole");
        
    };

    return (
        <AuthContext.Provider value={{ authState, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};
