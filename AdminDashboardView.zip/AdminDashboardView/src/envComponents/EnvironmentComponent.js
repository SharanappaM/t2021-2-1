
import LOGO1 from "../assets/logo.png"
import LOGO2 from "../assets/logo.png"




export const CompanyLOGO1 = () => LOGO1;
export const CompanyLOGO2 = () => LOGO2;
export const CompanyFullName = () => "Travercel Technologies Pvt Ltd";

export const CompanyName = ()=>"Travercel";











