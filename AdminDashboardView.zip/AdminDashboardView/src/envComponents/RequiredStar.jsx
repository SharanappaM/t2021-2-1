import React from 'react'

const RequiredStar = () => {
  return (
    <span style={{ color: "red" , fontWeight:"bold"}}>*</span>
  )
}

export default RequiredStar